package ru.job4j.snake;

enum Direction {
    LEFT, RIGHT, UP, DOWN
}
