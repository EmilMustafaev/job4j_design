package ru.job4j.map;

public record Subject(String name, int score) { }
