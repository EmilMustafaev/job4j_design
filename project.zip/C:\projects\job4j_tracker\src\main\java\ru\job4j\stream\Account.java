package ru.job4j.stream;

public record Account(String requisite, double balance) {
}
