package ru.job4j;

public class StudentInfo {
    public static void main(String[] args) {
        System.out.println("Emil Mustafaev");
        System.out.println("04.01.2001");
    }
}
