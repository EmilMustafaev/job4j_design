package ru.job4j.snake;

public record Cell(int x, int y) {
}
