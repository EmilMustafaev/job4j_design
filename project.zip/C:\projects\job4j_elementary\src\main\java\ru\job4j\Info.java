package ru.job4j;

public class Info {
    public static void main(String[] args) {
        System.out.println("20.02.2024");
    }
}
