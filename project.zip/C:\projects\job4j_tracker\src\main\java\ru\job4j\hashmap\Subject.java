package ru.job4j.hashmap;

public record Subject(String name, int score) {
}