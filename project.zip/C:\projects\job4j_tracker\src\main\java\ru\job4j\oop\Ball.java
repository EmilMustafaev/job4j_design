package ru.job4j.oop;

public class Ball {
    public void tryRun(boolean condition) {
        if (condition) {
            System.out.println("Колобка съели");
        } else {
            System.out.println("Колобок сбежал");
        }
    }
}
