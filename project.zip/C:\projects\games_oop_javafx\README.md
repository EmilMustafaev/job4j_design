This project demonstrates how to use Java Fx in OOP Style. 
All examples are popular games. (Snake, Chess, TicTacToe, SeeBattle and etc)

If you have any suggestions about this project, please, creating a new GitHub issue https://github.com/peterarsentev/games_oop_javafx/issues


## Snake

![ScreenShot](images/Snake.png)

## TicTacToe

![ScreenShot](images/TicTacToe.png)

## Chess

![ScreenShot](images/Chess.png)

## TODO

- SeaBattle
- PackMan
- Tetris
